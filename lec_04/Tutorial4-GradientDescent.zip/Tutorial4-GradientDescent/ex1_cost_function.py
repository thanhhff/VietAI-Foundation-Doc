
def cost_function(x):
	cost = 0
	# TODO: compute cost value of the following function: 3x^2 - 12x + 4


	return cost
