from ex2_derivative_function import *


def update_optimized_var(x_old, l_rate):
	x_new = 0
	# TODO: Compute new value x_new based on gradient value and learning rate


	return x_new
