
def derivative_function(x):
	der = 0
	# TODO: compute derivative value of the following function: 3x^2 - 12x + 4


	return der
